package com.qcb.services;

import com.qcb.entitys.User;

public interface IUserService {
	public User getUserById(int userId);
}

